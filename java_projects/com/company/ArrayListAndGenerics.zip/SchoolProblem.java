package com.company;

public class SchoolProblem
{
    public static void main(String[] args)
    {
        int a = 2;
        int b = 3;
        int c = -7;
        int d = 9;

        if (a * d < b*c )
            System.out.println("Halloween");
        System.out.println("Orange and Black");
        if ( a -c < d - b )

            System.out.print("SF Giants");
       // System.out.print("This always executes");
        else
            System.out.print ("Have Fun ");
        System.out.print("Celebrate");
    }

}




